package ma.ensa.projetws;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import ma.ensa.projetws.beans.Etudiant;

public class AddEtudiant extends AppCompatActivity implements View.OnClickListener {
    private EditText nom;
    private EditText prenom;
    private Spinner ville;
    private RadioButton m;
    private RadioButton f;
    private Button add;
    private RequestQueue requestQueue;

    // Update this URL to your actual server IP or domain
    String insertUrl = "http://10.0.2.2/volley/sourcefiles/ws/createEtudiant.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_etudiant);

        // Initialize views
        nom = findViewById(R.id.nom);
        prenom = findViewById(R.id.prenom);
        ville = findViewById(R.id.ville);
        add = findViewById(R.id.add);
        m = findViewById(R.id.m);
        f = findViewById(R.id.f);

        // Set click listener
        add.setOnClickListener(this);

        // Initialize request queue
        requestQueue = Volley.newRequestQueue(this);
    }

    @Override
    public void onClick(View v) {
        if (v == add) {
            if (validateInputs()) {
                sendRequest();
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendRequest() {
        StringRequest request = new StringRequest(Request.Method.POST, insertUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(TAG, response);
                        try {
                            Type type = new TypeToken<Collection<Etudiant>>() {}.getType();
                            Collection<Etudiant> etudiants = new Gson().fromJson(response, type);
                            if (etudiants != null) {
                                for (Etudiant e : etudiants) {
                                    Log.d(TAG, e.toString());
                                }
                                Toast.makeText(AddEtudiant.this, "Students added successfully!", Toast.LENGTH_SHORT).show();
                            } else {
                                Log.e(TAG, "No students found in response");
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Failed to parse response", e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley Error", error.toString());
                        Toast.makeText(AddEtudiant.this, "Error adding student", Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                String sexe = m.isChecked() ? "homme" : "femme";
                HashMap<String, String> params = new HashMap<>();
                params.put("nom", nom.getText().toString());
                params.put("prenom", prenom.getText().toString());
                params.put("ville", ville.getSelectedItem().toString());
                params.put("sexe", sexe);
                return params;
            }
        };

        requestQueue.add(request);
    }

    private boolean validateInputs() {
        return !nom.getText().toString().isEmpty() &&
                !prenom.getText().toString().isEmpty() &&
                ville.getSelectedItem() != null;
    }
}