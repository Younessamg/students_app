package ma.ensa.projetws.adapters;


import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;

import java.util.List;

import ma.ensa.projetws.R;
import ma.ensa.projetws.beans.Etudiant;

public class EtudiantAdapter extends RecyclerView.Adapter<EtudiantAdapter.EtudiantViewHolder> {

    private List<Etudiant> etudiants;
    private Context context;
    private OnEtudiantActionListener actionListener;

    public interface OnEtudiantActionListener {
        void onUpdateEtudiant(Etudiant etudiant, int position);
        void onDeleteEtudiant(Etudiant etudiant, int position);
    }

    public EtudiantAdapter(List<Etudiant> etudiants, Context context, OnEtudiantActionListener actionListener) {
        this.etudiants = etudiants;
        this.context = context;  // Ensure this is the Activity context
        this.actionListener = actionListener;
    }

    @NonNull
    @Override
    public EtudiantViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_etudiant, parent, false);
        return new EtudiantViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EtudiantViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Etudiant etudiant = etudiants.get(position);
        holder.nom.setText(etudiant.getNom());
        holder.prenom.setText(etudiant.getPrenom());
        holder.ville.setText(etudiant.getVille());
        holder.sexe.setText(etudiant.getSexe());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call showPopupMenu with the correct context
                showPopupMenu(v, etudiant, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return etudiants.size();
    }

    private void showPopupMenu(View view, Etudiant etudiant, int position) {
        PopupMenu popupMenu = new PopupMenu(context, view);
        popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                try {
                    // Use if-else instead of switch-case
                    if (item.getItemId() == R.id.action_modify) {
                        showEditDialog(etudiant, position);
                        return true;
                    } else if (item.getItemId() == R.id.action_delete) {
                        if (actionListener != null) {
                            actionListener.onDeleteEtudiant(etudiant, position);
                        }
                        return true;
                    } else {
                        // Handle unrecognized menu items if necessary
                        return false;
                    }
                } catch (Exception e) {
                    Log.e("EtudiantAdapter", "Error in popup menu item click: " + e.getMessage());
                    return false;
                }
            }
        });
        popupMenu.show();
    }

    private void showEditDialog(Etudiant etudiant, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);  // Use Activity context here
        builder.setTitle("Modifier l'étudiant");

        View viewInflated = LayoutInflater.from(context).inflate(R.layout.dialog_edit_etudiant, null);
        EditText inputNom = viewInflated.findViewById(R.id.input_nom);
        EditText inputPrenom = viewInflated.findViewById(R.id.input_prenom);
        EditText inputVille = viewInflated.findViewById(R.id.input_ville);
        EditText inputSexe = viewInflated.findViewById(R.id.input_sexe);

        inputNom.setText(etudiant.getNom());
        inputPrenom.setText(etudiant.getPrenom());
        inputVille.setText(etudiant.getVille());
        inputSexe.setText(etudiant.getSexe());

        builder.setView(viewInflated);

        builder.setPositiveButton("Modifier", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Update student data and notify listener
                etudiant.setNom(inputNom.getText().toString());
                etudiant.setPrenom(inputPrenom.getText().toString());
                etudiant.setVille(inputVille.getText().toString());
                etudiant.setSexe(inputSexe.getText().toString());

                if (actionListener != null) {
                    actionListener.onUpdateEtudiant(etudiant, position);
                }
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    static class EtudiantViewHolder extends RecyclerView.ViewHolder {
        TextView nom;
        TextView prenom;
        TextView ville;
        TextView sexe;

        public EtudiantViewHolder(@NonNull View itemView) {
            super(itemView);
            nom = itemView.findViewById(R.id.nom);
            prenom = itemView.findViewById(R.id.prenom);
            ville = itemView.findViewById(R.id.ville);
            sexe = itemView.findViewById(R.id.sexe);
        }
    }
}
